#ifndef LEXICAL_ANALYZER_H
#define LEXICAL_ANALYZER_H

#define MAX_SOURCE 10000
#define MAX_LINE 500
#define MAX_TOKEN 100

void lexical_analyzer(char source[]);

#endif