#include <stdio.h>
#include <string.h>
#include "lexical_analyzer.h"

int main()
{
    char source[MAX_SOURCE];
    char line[MAX_LINE];
    int index = 0;

    printf("Enter the C program:\n");

    while (1)
    {
        fgets(line, MAX_LINE, stdin);

        line[strcspn(line, "\n")] = '\0';

        if (strcmp(line, "END") == 0)
        {
            break;
        }

        if (index + strlen(line) + 2 >= MAX_SOURCE)
        {
            printf("Program size is too large.\n");
            return 1;
        }

        strcpy(source + index, line);
        index = index + strlen(line);

        source[index] = '\n';
        index++;
        source[index] = '\0';
    }

    printf("\nLexical Analysis:\n\n");

    lexical_analyzer(source);

    return 0;
}