#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "lexical_analyzer.h"

int check_keyword(char word[])
{
    char keywords[][15] = {
        "auto", "break", "case", "char", "const",
        "continue", "default", "do", "double", "else",
        "enum", "extern", "float", "for", "goto",
        "if", "int", "long", "register", "return",
        "short", "signed", "sizeof", "static", "struct",
        "switch", "typedef", "union", "unsigned", "void",
        "volatile", "while"
    };

    int i;

    for (i = 0; i < 32; i++)
    {
        if (strcmp(word, keywords[i]) == 0)
        {
            return 1;
        }
    }

    return 0;
}

int check_identifier(char word[])
{
    int i;

    if (!(isalpha(word[0]) || word[0] == '_'))
    {
        return 0;
    }

    for (i = 1; word[i] != '\0'; i++)
    {
        if (!(isalnum(word[i]) || word[i] == '_'))
        {
            return 0;
        }
    }

    return 1;
}

void check_word(char word[])
{
    if (check_keyword(word))
    {
        printf("%-15s : Keyword\n", word);
    }
    else
    {
        printf("%-15s : Identifier\n", word);
    }
}

void check_number(char number[])
{
    int i;
    int valid = 1;

    if (number[0] == '0' &&
        (number[1] == 'b' || number[1] == 'B'))
    {
        if (number[2] == '\0')
        {
            valid = 0;
        }

        for (i = 2; number[i] != '\0'; i++)
        {
            if (number[i] != '0' && number[i] != '1')
            {
                valid = 0;
            }
        }

        if (valid)
        {
            printf("%-15s : Binary Constant\n", number);
        }
        else
        {
            printf("ERROR : Invalid binary number %s\n", number);
        }
    }
    else if (number[0] == '0' &&
             (number[1] == 'x' || number[1] == 'X'))
    {
        if (number[2] == '\0')
        {
            valid = 0;
        }

        for (i = 2; number[i] != '\0'; i++)
        {
            if (!isxdigit(number[i]))
            {
                valid = 0;
            }
        }

        if (valid)
        {
            printf("%-15s : Hexadecimal Constant\n", number);
        }
        else
        {
            printf("ERROR : Invalid hexadecimal number %s\n", number);
        }
    }
    else if (number[0] == '0' && number[1] != '\0')
    {
        for (i = 1; number[i] != '\0'; i++)
        {
            if (number[i] < '0' || number[i] > '7')
            {
                valid = 0;
            }
        }

        if (valid)
        {
            printf("%-15s : Octal Constant\n", number);
        }
        else
        {
            printf("ERROR : Invalid octal number %s\n", number);
        }
    }
    else
    {
        if (isalpha(number[1]))
        {
            printf("ERROR : Variable should not start with a number %s\n",
                   number);
            return;
        }

        for (i = 0; number[i] != '\0'; i++)
        {
            if (!isdigit(number[i]))
            {
                valid = 0;
            }
        }

        if (valid)
        {
            printf("%-15s : Decimal Constant\n", number);
        }
        else
        {
            printf("ERROR : Decimal number should not contain alphabets %s\n",
                   number);
        }
    }
}

int is_operator(char ch)
{
    if (ch == '+' || ch == '-' || ch == '*' ||
        ch == '/' || ch == '%' || ch == '=' ||
        ch == '<' || ch == '>' || ch == '!' ||
        ch == '&' || ch == '|' || ch == '^' ||
        ch == '~')
    {
        return 1;
    }

    return 0;
}

void print_operator(char op[])
{
    if (strcmp(op, "=") == 0 ||
        strcmp(op, "+=") == 0 ||
        strcmp(op, "-=") == 0 ||
        strcmp(op, "*=") == 0 ||
        strcmp(op, "/=") == 0 ||
        strcmp(op, "%=") == 0)
    {
        printf("%-15s : Assignment Operator\n", op);
    }
    else if (strcmp(op, "+") == 0 ||
             strcmp(op, "-") == 0 ||
             strcmp(op, "*") == 0 ||
             strcmp(op, "/") == 0 ||
             strcmp(op, "%") == 0 ||
             strcmp(op, "++") == 0 ||
             strcmp(op, "--") == 0)
    {
        printf("%-15s : Arithmetic Operator\n", op);
    }
    else if (strcmp(op, "<") == 0 ||
             strcmp(op, ">") == 0 ||
             strcmp(op, "<=") == 0 ||
             strcmp(op, ">=") == 0 ||
             strcmp(op, "==") == 0 ||
             strcmp(op, "!=") == 0)
    {
        printf("%-15s : Relational Operator\n", op);
    }
    else if (strcmp(op, "&&") == 0 ||
             strcmp(op, "||") == 0 ||
             strcmp(op, "!") == 0)
    {
        printf("%-15s : Logical Operator\n", op);
    }
    else
    {
        printf("%-15s : Bitwise Operator\n", op);
    }
}

void check_operator(char source[], int *i)
{
    char op[3];

    op[0] = source[*i];
    op[1] = '\0';
    op[2] = '\0';

    if (source[*i + 1] == '=' ||
        (source[*i] == '+' && source[*i + 1] == '+') ||
        (source[*i] == '-' && source[*i + 1] == '-') ||
        (source[*i] == '&' && source[*i + 1] == '&') ||
        (source[*i] == '|' && source[*i + 1] == '|'))
    {
        op[1] = source[*i + 1];
        op[2] = '\0';
        *i = *i + 1;
    }

    print_operator(op);

    *i = *i + 1;
}

void check_brackets(char source[])
{
    int curly = 0;
    int round = 0;
    int square_open = 0;
    int square_line = 0;
    int line = 1;
    int i;

    for (i = 0; source[i] != '\0'; i++)
    {
        if (source[i] == '{')
        {
            curly++;
        }
        else if (source[i] == '}')
        {
            curly--;

            if (curly < 0)
            {
                printf("ERROR : Unexpected } at line %d\n", line);
                curly = 0;
            }
        }
        else if (source[i] == '(')
        {
            round++;
        }
        else if (source[i] == ')')
        {
            round--;

            if (round < 0)
            {
                printf("ERROR : Unexpected ) at line %d\n", line);
                round = 0;
            }
        }
        else if (source[i] == '[')
        {
            square_open = 1;
            square_line = line;
        }
        else if (source[i] == ']')
        {
            if (square_open == 1)
            {
                if (line != square_line)
                {
                    printf("ERROR : [ and ] must be on the same line\n");
                }

                square_open = 0;
            }
            else
            {
                printf("ERROR : Unexpected ] at line %d\n", line);
            }
        }

        if (source[i] == '\n')
        {
            line++;
        }
    }

    if (curly > 0)
    {
        printf("ERROR : Curly braces are not properly closed\n");
    }

    if (round > 0)
    {
        printf("ERROR : Parentheses are not properly closed\n");
    }

    if (square_open == 1)
    {
        printf("ERROR : Square bracket ] is missing\n");
    }
}

void lexical_analyzer(char source[])
{
    int i = 0;
    int j;
    char word[MAX_TOKEN];

    while (source[i] != '\0')
    {
        if (isspace(source[i]))
        {
            i++;
        }
        else if (isalpha(source[i]) || source[i] == '_')
        {
            j = 0;

            while (isalnum(source[i]) || source[i] == '_')
            {
                word[j] = source[i];
                j++;
                i++;
            }

            word[j] = '\0';

            check_word(word);
        }
        else if (isdigit(source[i]))
        {
            j = 0;

            while (isalnum(source[i]))
            {
                word[j] = source[i];
                j++;
                i++;
            }

            word[j] = '\0';

            check_number(word);
        }
        else if (is_operator(source[i]))
        {
            check_operator(source, &i);
        }
        else if (source[i] == '(' || source[i] == ')' ||
                 source[i] == '{' || source[i] == '}' ||
                 source[i] == '[' || source[i] == ']' ||
                 source[i] == ';' || source[i] == ',' ||
                 source[i] == ':')
        {
            printf("%-15c : Special Character\n", source[i]);
            i++;
        }
        else if (source[i] == '"')
        {
            j = 0;
            i++;

            while (source[i] != '"' && source[i] != '\0')
            {
                word[j] = source[i];
                j++;
                i++;
            }

            if (source[i] == '"')
            {
                i++;
            }

            word[j] = '\0';

            printf("%-15s : String\n", word);
        }
        else
        {
            printf("ERROR : Invalid character %c\n", source[i]);
            i++;
        }
    }

    check_brackets(source);
}